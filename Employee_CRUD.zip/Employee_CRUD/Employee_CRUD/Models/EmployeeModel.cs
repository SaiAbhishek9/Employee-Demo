﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Employee_CRUD.Models
{
    public class EmployeeModel
    {
       
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name ="Employee Name :")]
        public string EmployeeName { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Employee Age :")]

        public DateTime? EmployeeAge { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Employee Gender :")]

        public string EmployeeGender { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Employee Address :")]

        public string EmployeeAddress { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Employee State :")]

        public string EmployeeState { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Employee City :")]

        public string EmployeeCity { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Employee Hobbies :")]

        public string EmployeeHobbies { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name = "Employee TechSkills :")]

        public List<string> EmployeeTechskills { get; set; }

        public List<Hobby> Hobbies { get; set; }


        public EmployeeModel()
        {
            this.Hobbies = new List<Hobby>();
            this.Hobbies.Add(new Hobby { HobbyID = 1, HobbyName = "Cricket" });
            this.Hobbies.Add(new Hobby { HobbyID = 2, HobbyName = "Gardening" });
            this.Hobbies.Add(new Hobby { HobbyID = 3, HobbyName = "Cooking" });
        }

    }
}