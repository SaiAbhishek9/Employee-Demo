﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Employee_CRUD.Models
{
    public class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int Add_Employee(EmployeeModel model)
        {
            try
            {
                con.Open();
                SqlCommand com_add = new SqlCommand("add_employee", con);
                com_add.CommandType = CommandType.StoredProcedure;
                com_add.Parameters.AddWithValue("@name", model.EmployeeName);
                com_add.Parameters.AddWithValue("@age", model.EmployeeAge);
                com_add.Parameters.AddWithValue("@gender", model.EmployeeGender);
                com_add.Parameters.AddWithValue("@address", model.EmployeeAddress);
                com_add.Parameters.AddWithValue("@state", model.EmployeeState);
                com_add.Parameters.AddWithValue("@city", model.EmployeeCity);
                string hobbies = string.Empty;
                foreach(var h in model.Hobbies)
                {
                    if (h.Status)
                    {
                        if (hobbies == string.Empty)
                        {
                            hobbies = h.HobbyName;
                        }
                        else
                        {
                            hobbies = hobbies + "," + h.HobbyName;
                        }
                    }
                }
                com_add.Parameters.AddWithValue("@hobbies", hobbies);
                string skills = string.Empty;
                foreach (var s in model.EmployeeTechskills)
                {
                    
                        if (skills == string.Empty)
                        {
                            skills = s;
                        }
                        else
                        {
                            skills = skills + "," + s;
                        }
                }
            

                com_add.Parameters.AddWithValue("@techskills", skills);


                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_add.Parameters.Add(para_return);
                
                com_add.ExecuteNonQuery();
                int id = Convert.ToInt32(para_return.Value);
                model.EmployeeId = id;
                return id;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }

        public List<EmployeeModel> Search_Employee(string name)
        {
            try
            {
                con.Open();
                SqlCommand com_search = new SqlCommand("search_employee", con);
                com_search.CommandType = CommandType.StoredProcedure;
                List<EmployeeModel> elist = new List<EmployeeModel>();
                com_search.Parameters.AddWithValue("@name", name);
                SqlDataReader dr = com_search.ExecuteReader();
                while (dr.Read())
                {
                    EmployeeModel e = new EmployeeModel();
                    e.EmployeeId = dr.GetInt32(0);
                    e.EmployeeName = dr.GetString(1);
                    e.EmployeeAge = dr.GetDateTime(2);
                    e.EmployeeGender = dr.GetString(3);
                    e.EmployeeAddress = dr.GetString(4);
                    e.EmployeeState = dr.GetString(5);
                    e.EmployeeCity = dr.GetString(6);
                    e.EmployeeHobbies = dr.GetString(7);
                    e.EmployeeTechskills = dr.GetString(8).Split(',').ToList();

                    elist.Add(e);
                }
                return elist;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public EmployeeModel Find_Employee(int id)
        {
            try
            {
                con.Open();
                SqlCommand com_search = new SqlCommand("find_employee", con);
                com_search.CommandType = CommandType.StoredProcedure;
                com_search.Parameters.AddWithValue("@id", id);
                SqlDataReader dr = com_search.ExecuteReader();
                if (dr.Read())
                {
                    EmployeeModel e = new EmployeeModel();
                    e.EmployeeId = dr.GetInt32(0);
                    e.EmployeeName = dr.GetString(1);
                    e.EmployeeAge = dr.GetDateTime(2);
                    e.EmployeeGender = dr.GetString(3);
                    e.EmployeeAddress = dr.GetString(4);
                    e.EmployeeState = dr.GetString(5);
                    e.EmployeeCity = dr.GetString(6);
                    e.EmployeeHobbies = dr.GetString(7);
                    e.EmployeeTechskills = dr.GetString(8).Split(',').ToList() ;

                    return e;
                }
                return null;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Update_Employee(EmployeeModel model)
        {
            try
            {
                con.Open();
                SqlCommand com_edit = new SqlCommand("update_employee", con);
                com_edit.CommandType = CommandType.StoredProcedure;
                com_edit.Parameters.AddWithValue("@id", model.EmployeeId);
                com_edit.Parameters.AddWithValue("@age", model.EmployeeAge);
                com_edit.Parameters.AddWithValue("@address", model.EmployeeAddress);
                com_edit.Parameters.AddWithValue("@state", model.EmployeeState);
                com_edit.Parameters.AddWithValue("@city", model.EmployeeCity);
                string hobbies = string.Empty;
                foreach (var h in model.Hobbies)
                {
                    if (h.Status)
                    {
                        if (hobbies == string.Empty)
                        {
                            hobbies = h.HobbyName;
                        }
                        else
                        {
                            hobbies = hobbies + "," + h.HobbyName;
                        }
                    }
                }
                com_edit.Parameters.AddWithValue("@hobbies", hobbies);
                string skills = string.Empty;
                foreach (var s in model.EmployeeTechskills)
                {

                    if (skills == string.Empty)
                    {
                        skills = s;
                    }
                    else
                    {
                        skills = skills + "," + s;
                    }
                }


                com_edit.Parameters.AddWithValue("@techskills", skills);
                SqlParameter returndata = new SqlParameter();
                returndata.Direction = ParameterDirection.ReturnValue;
                com_edit.Parameters.Add(returndata);
                com_edit.ExecuteNonQuery();
                int count = Convert.ToInt32(returndata.Value);
              
                

                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
                
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Delete_Employee(int id)
        {
            try
            {
                con.Open();
                SqlCommand com_del = new SqlCommand("delete_employee", con);
                com_del.CommandType = CommandType.StoredProcedure;
                com_del.Parameters.AddWithValue("@id", id);
                int del = com_del.ExecuteNonQuery();
                if (del > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }



    }
}