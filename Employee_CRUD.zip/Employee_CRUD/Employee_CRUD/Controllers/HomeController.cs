﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Employee_CRUD.Models;

namespace Employee_CRUD.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {

            return View();
        }

        public ActionResult Add()
        {
            List<SelectListItem> plist = new List<SelectListItem>();
            plist.Add(new SelectListItem { Text = "Select", Value = "" });
            plist.Add(new SelectListItem { Text = "AndhraPradesh", Value = "AndhraPradesh" });
            plist.Add(new SelectListItem { Text = "Karnataka", Value = "Karnataka" });
            plist.Add(new SelectListItem { Text = "Telangana", Value = "Telangana" });
            plist.Add(new SelectListItem { Text = "TamilNadu", Value = "TamilNadu" });
            plist.Add(new SelectListItem { Text = "Kerala", Value = "Kerala" });

            var Skills = new List<SelectListItem>();
            Skills.Add(new SelectListItem { Text = "Select", Value = "" });
            Skills.Add(new SelectListItem { Text = "DotNET", Value = "DotNET" });
            Skills.Add(new SelectListItem { Text = "JQuery", Value = "JQuery" });
            Skills.Add(new SelectListItem { Text = "HTML", Value = "HTML" });
            ViewBag.skills = Skills;
            ViewBag.plist = plist;

            return View(new EmployeeModel() {EmployeeAge=null });
        }
        [HttpPost]
        public ActionResult Add(EmployeeModel model)
        {
            EmployeeDAL dal = new EmployeeDAL();        
                    dal.Add_Employee(model);
                    ViewBag.msg = "Employee Added..." + " " + "Id is" + model.EmployeeId.ToString();
            return View("EmployeeAddedView");
        }
    

        public ActionResult Search()
        {
            return View();

        }
        [HttpPost]
        public ActionResult Search(string name)
        {
            EmployeeDAL dal = new EmployeeDAL();
            List<EmployeeModel> plist = dal.Search_Employee(name);
            return View(plist);
        }
        
        public ActionResult Find(int id)
        {
            EmployeeDAL dal = new EmployeeDAL();
            EmployeeModel model = dal.Find_Employee(id);
            return View(model);
        }
        public ActionResult Update(int id)
        {
            EmployeeDAL dal = new EmployeeDAL();
            EmployeeModel model = dal.Find_Employee(id);

            List<SelectListItem> plist = new List<SelectListItem>();
            plist.Add(new SelectListItem { Text = "Select", Value = "" });
            plist.Add(new SelectListItem { Text = "AndhraPradesh", Value = "AndhraPradesh" });
            plist.Add(new SelectListItem { Text = "Karnataka", Value = "Karnataka" });
            plist.Add(new SelectListItem { Text = "Telangana", Value = "Telangana" });
            plist.Add(new SelectListItem { Text = "TamilNadu", Value = "TamilNadu" });
            plist.Add(new SelectListItem { Text = "Kerala", Value = "Kerala" });

            var Skills = new List<SelectListItem>();
            Skills.Add(new SelectListItem { Text = "Select", Value = "" });
            Skills.Add(new SelectListItem { Text = "DotNET", Value = "DotNET" });
            Skills.Add(new SelectListItem { Text = "JQuery", Value = "JQuery" });
            Skills.Add(new SelectListItem { Text = "HTML", Value = "HTML" });

            foreach (var s in model.EmployeeTechskills)
            {
                if(Skills.FirstOrDefault(ss => ss.Text == s)!=null)
                    {
                    Skills.FirstOrDefault(ss => ss.Text == s).Selected = true;
                }
            }

            foreach(var h in model.Hobbies)
            {
             if(model.EmployeeHobbies.Contains(h.HobbyName))
                {
                    h.Status = true;
                }
             
            }
           
            ViewBag.skills = Skills;
            ViewBag.plist = plist;

            
            return View(model);

        }
        [HttpPost]
        public ActionResult Update(EmployeeModel model)
        {
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.Update_Employee(model);
            if (status)
            {
                return View("EmployeeUpdated");
            }
            else
            {
                ViewBag.msg = "Not Updated";

                List<SelectListItem> plist = new List<SelectListItem>();
                plist.Add(new SelectListItem { Text = "Select", Value = "" });
                plist.Add(new SelectListItem { Text = "AndhraPradesh", Value = "AndhraPradesh" });
                plist.Add(new SelectListItem { Text = "Karnataka", Value = "Karnataka" });
                plist.Add(new SelectListItem { Text = "Telangana", Value = "Telangana" });
                plist.Add(new SelectListItem { Text = "TamilNadu", Value = "TamilNadu" });
                plist.Add(new SelectListItem { Text = "Kerala", Value = "Kerala" });

                var Skills = new List<SelectListItem>();
                Skills.Add(new SelectListItem { Text = "Select", Value = "" });
                Skills.Add(new SelectListItem { Text = "DotNET", Value = "DotNET" });
                Skills.Add(new SelectListItem { Text = "JQuery", Value = "JQuery" });
                Skills.Add(new SelectListItem { Text = "HTML", Value = "HTML" });

                foreach (var s in model.EmployeeTechskills)
                {
                    if (Skills.FirstOrDefault(ss => ss.Text == s) != null)
                    {
                        Skills.FirstOrDefault(ss => ss.Text == s).Selected = true;
                    }
                }

                //foreach (var h in model.Hobbies)
                //{
                //    if (model.EmployeeHobbies.Contains(h.HobbyName))
                //    {
                //        h.Status = true;
                //    }

                //}

                ViewBag.skills = Skills;
                ViewBag.plist = plist;


                return View(model);
            }
        }

        public ActionResult Delete(int id)
        {
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.Delete_Employee(id);
            if (status)
            {
                ViewBag.msg = "Employee Deleted";
                return View("EmployeeDeleted");
            }
            else
            {
                ViewBag.fail = "Failed to delete";
                return View();
            }
        }

    }
    
}