﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Employee_CRUD.Models
{
   

    public class Hobby
    {
        [Required(ErrorMessage = "*")]

        public int HobbyID { get; set; }

        [Required(ErrorMessage = "*")]

        public string HobbyName { get; set; }

        [Required(ErrorMessage = "*")]

        public bool Status { get; set; }
    }

}